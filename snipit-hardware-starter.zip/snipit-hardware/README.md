# Snipit V1 PCB Design — Rev A

**Preliminary design. Not fabrication-ready.** 80 mm, 576-dot thermal printing; 2S protected lithium pack; camera and removable Cashino controller PCB. Cost target <= $70 at ~150 units is not yet validated.

## Folder map
- `pcb/` KiCad starter project, **empty schematic** pending verified part drawings
- `docs/` architecture, connector proposals, power and safety requirements
- `bom/` provisional sourcing CSV; no unverified prices presented as quotes
- `mechanical/` paper path and board envelope constraints
- `manufacturing/` release checklist, no Gerbers yet
- `datasheets/` documents needed before schematic signoff

## Critical next steps
1. Obtain controller quote, UART protocol, protections and dimensions.
2. Verify exact 30-pin mechanism FPC drawing and contact orientation.
3. Capture v0 current traces across battery SOC and worst-case patterns.
4. Validate ESP32-P4 and sensor module STROBE/FREX and JPEG pipeline.
5. Complete safety, battery, ERC/DRC and mechanical reviews before ordering.
