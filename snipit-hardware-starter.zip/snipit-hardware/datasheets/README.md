# Datasheets needed
Official selected ESP32-P4 variant, selected camera module including STROBE/FREX pins, BQ25887, selected buck and LED driver, LCD, USB-C, microSD socket, 2S certified pack, Cashino controller UART/safety/power documentation, selected 80mm mechanism and mating FPC drawing. Track revision, URL and redistribution permission before committing supplier PDFs.
