# Architecture recommendation

Option B: custom camera motherboard + replaceable Cashino controller connected over UART. Vendor controller owns head timing and compensation; demand proof of independent safety interlocks. This is conditional on acceptable NRE, per-unit cost, dimensions, input-voltage range, lead time and documentation. Option A (direct drive) offers possible long-run BOM savings but needs additional head timing, stepper, thermal and fault validation.

At 150 units, every $5 controller premium adds $750. Neither controller pricing nor engineering NRE has been quoted.

```
USB-C (data) -> ESP32-P4 candidate -> MIPI camera / SPI LCD / microSD / I2C UI
USB-C (5V) -> 2S boost charger -> protected 2S pack -> 3V3 buck + camera rails
                                               -> protected VH switch -> controller -> 80mm head/motor
MCU UART/status/enable -------------------------------> controller
MCU flash control -> warm LED constant-current driver
```

No wireless or AI in v1. Capture to PSRAM and print without SD. Flash charge and printing must be mutually exclusive.
