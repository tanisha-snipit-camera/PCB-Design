# Proposed interfaces — pinouts NOT approved

## J_PRN 8-way keyed low-current camera/controller link (PROPOSED)
1 GND; 2 GND; 3 MCU_UART_TX (3.3V); 4 MCU_UART_RX (3.3V); 5 PRN_ENABLE; 6 PRN_READY; 7 PRN_FAULT; 8 PRN_INTERLOCK_OK monitor. Actual Cashino protocol/pins are unknown. PRN_ENABLE is not a safety interlock.

## J_PRN_PWR separate high-current keyed connector (PROPOSED)
1 PACK_SWITCHED+; 2 PACK_SWITCHED+; 3 RETURN; 4 RETURN. Final connector and copper rating depend on measured current and connector derating.

## J_UI 12-way replaceable control board (PROPOSED)
1 GND; 2 SWITCHED_3V3; 3 I2C_SCL; 4 I2C_SDA; 5 UI_INT_N; 6 UI_RESET_N; 7 SHUTTER_HALF_N; 8 SHUTTER_FULL_N; 9 ENC_A; 10 ENC_B; 11 SPARE; 12 GND. Use an I2C GPIO expander; final mapping requires expander choice and ESD design.

## Camera/display
Camera: MIPI CSI lanes and clock, I2C, reset/power-down, sensor-specific core/analog/IO rails, STROBE and FREX if module exposes them. LCD: SPI SCK/MOSI/CS/DC, reset, backlight PWM and power. Connector footprints require module drawings.

## 30-pin mechanism FPC — PARTIAL user-supplied facts only
VH 6,7,25,26; GND 10,11,21,22; Vdd 15; motor phases 27–30. Remaining lines include DI/CLK/LAT/DO, STB1–STB5, TM, PHK/VSEN/PHE and -103 platen SW1/SW2. **Do not wire unspecified pins or assume connector contact orientation.** Verify against mechanism datasheet and selected supplier variant.
