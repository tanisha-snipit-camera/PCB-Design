# Power and safety — design requirements, not approved circuit

USB-C 5V input with CC1/CC2 5.1k sink pulldowns and USB2 HS low-capacitance ESD. Candidate 5V-input boost-mode 2S charger BQ25887; evaluate charge termination below 8.4V and accuracy/transients against head 8.5V absolute maximum. Use certified protected/balanced 2S pack and pack thermistor. SYS_3V3 synchronous buck; sensor rails per selected module. Printer VH independent protected high-side switch/eFuse, current sense and hardware cut-off. 3000–4000K CRI>=80 warm LED ~1A 50–150ms pending thermal validation. No xenon HV on first board.

Reported vendor printer system: 4A peak / 2A average at 9V; head-only 2.4A at 7.2V with 64 concurrent dots; motor max 1A. 9V x 4A / 8.4V is ~4.3A if power is constant, so do not assume 3.7A is universal peak. v0 measurements must bound startup, dense print and low SOC; earlier 8.6A unthrottled fault estimate requires independent current limiting.

Independent hardware conditions for VH: battery OK AND current OK AND head temperature OK AND paper present AND platen closed AND controller ready AND no flash charging. Unplugged/open/short sensors must fail OFF. Power Vdd before VH; disable strobes, switch VH OFF and discharge before Vdd OFF. Thermistor 30k at 25C B3950; head max temperature and comparator threshold must be obtained from vendor. If controller cannot document independent protection, add external gating and reconsider architecture.

Fault injection: MCU GPIO stuck high, sensor unplugged, NTC open/short, paper out, platen open, motor jam, overcurrent, brownout, charging fault and switch failure. Qualify battery to applicable standards with competent engineering review.
