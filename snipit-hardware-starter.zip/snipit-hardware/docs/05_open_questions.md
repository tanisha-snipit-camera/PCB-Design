# Release blockers

| Decision | Evidence required |
|---|---|
| Cashino controller | 10/150/1k quote, NRE, MOQ, UART protocol, 2S voltage range, safety schematic/evidence, dimensions, lead time |
| Printer mechanism | Exact 30-pin drawing/contact orientation, 80mm mechanical STEP, head max temperature and motor waveform |
| Battery and charger | Certified pack, capacity, thermistor, charge termination accuracy, thermal and current limits |
| Power | v0 startup/peak/average current at min/mid/max SOC, dense patterns, charge-print mutual exclusion |
| Sensor | Actual 5MP module, MIPI lane config, exposed STROBE/FREX and flash timing |
| Processor | Exact ESP32-P4 variant/PSRAM, USB MSC >1MB/s and JPEG pipeline |
| Mechanical | 80mm width x up to 60mm OD roll and bottom exit vs pocket-camera body |
| Cost | Mechanism/controller/pack/PCB/assembly/test quotes at 1/10/150/1k |
