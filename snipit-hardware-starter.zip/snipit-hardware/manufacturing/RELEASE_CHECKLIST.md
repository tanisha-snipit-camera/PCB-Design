# Manufacturing HOLD
No approved Gerbers. Do not order boards from starter files.

- [ ] Controller and mechanism drawings verified
- [ ] Actual v0 current/thermal measurements reviewed
- [ ] Full schematics captured and ERC passed
- [ ] Battery/charger and independent printer interlock reviewed
- [ ] PCB outline and mechanical interference checked
- [ ] Stackup, MIPI and USB impedance approved
- [ ] PCB DRC, power/thermal review and fault testing passed
- [ ] Component sourcing and alternates confirmed
- [ ] EMC pre-scan and compliance plan reviewed
- [ ] Approved Gerbers, drill, assembly drawing, pick-place and BOM released
